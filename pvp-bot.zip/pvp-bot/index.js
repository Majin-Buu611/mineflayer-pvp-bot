const mineflayer = require('mineflayer');
const armorManager = require('mineflayer-armor-manager');
const pvp = require('mineflayer-pvp').plugin;
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const autoEat = require('mineflayer-auto-eat');

const bot = mineflayer.createBot({
host: process.argv[2],
port: process.argv[3],
username: process.argv[4],
password: process.argv[5],
logErrors: false
});

bot.loadPlugin(pathfinder);
bot.loadPlugin(pvp);
bot.loadPlugin(armorManager);
bot.loadPlugin(autoEat);

bot.once('spawn', () => {
bot.autoEat.options = {
priority: 'foodPoints',
startAt:14,
bannedFoods: []
}
});

bot.on('playerCollect', (collector, itemDrop) => {
console.log(bot.inventory.items());
setTimeout(() => {
console.log(bot.inventory.items());

const sword = bot.inventory.items().find(item => item.name.includes('sword'));
if (sword) bot.equip(sword, 'hand');
}, 150);
});

bot.on('chat', (username, message) => {
if (message === 'fight me') {
const players = bot.players[username];

if (!players) {
bot.chat("I can't see you.");
return;
}

bot.pvp.attack(players.entity);
}

if (message === 'stop') {
bot.pvp.stop();
}
});


bot.on('health', () => {
if (bot.food === 20) bot.autoEat.disable();
else bot.autoEat.enable();
});