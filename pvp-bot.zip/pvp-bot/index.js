const mineflayer = require('mineflayer');
const armorManager = require('mineflayer-armor-manager');
const pvp = require('mineflayer-pvp').plugin;
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const autoEat = require('mineflayer-auto-eat');

const bot = mineflayer.createBot({
host: process.argv[2],
port: process.argv[3],
username: process.argv[4],
password: process.argv[5],
logErrors: false
});

bot.loadPlugin(pathfinder);
bot.loadPlugin(pvp);
bot.loadPlugin(armorManager);
bot.loadPlugin(autoEat);

bot.once('spawn', () => {
bot.autoEat.options = {
priority: 'foodPoints',
startAt:14,
bannedFoods: []
}
});



bot.on('chat', (username, message) => {
if (message === 'fight me') {
const player = bot.players[username];

if (!player) {
bot.chat("I can't see you.");
return;
}

bot.pvp.attack(player.entity);
}

if (message === 'stop') {
bot.pvp.stop();
}
});


bot.on('health', () => {
if (bot.food === 20) bot.autoEat.disable();
else bot.autoEat.enable();
});

bot.on('attackedTarget', () => {
  bot.setControlState('sprint', false);
  bot.setControlState('sprint', true);
});

bot.on('attackedTarget', () => {
  const axe = bot.inventory.items().find(item => item.name.includes('axe'));
if (axe) bot.equip(axe, 'hand');
});

bot.on('startedAttacking', () => {
  const axe = bot.inventory.items().find(item => item.name.includes('axe'));
  if(axe) bot.equip(axe, 'hand');
});